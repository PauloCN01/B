const routes = require('express').Router();
const get = require('../controller/get');
const get2 = require('../controller/get2');
const get3 = require('../controller/get3');

routes.get('/Rota1', get);
routes.get('/Rota2', get2);
routes.get('/Rota3', get3);

module.exports = routes;