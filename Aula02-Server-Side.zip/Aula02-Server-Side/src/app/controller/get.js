module.exports = (req, res) => {
    res.send(`
        <html>
            <head>
                <meta charset="utf-8">
            </head>
            <body>
                <h1>Rota Pacifista</h1>
                <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT3DMLo9SnE0-d0J9xjTwQpHAhP_r10CmkxQQ&s" alt="" height="500px">
            </body>
        </html>
    `);
}
   