module.exports = (req, res) => {
    res.send(`
        <html>
            <head>
                <meta charset="utf-8">
            </head>
            <body>
                <h1>Rota Genocida</h1>
                <img src="https://i1.sndcdn.com/artworks-3YkSQ9ziTy8dyxa9-JTyMag-t500x500.jpg" alt="">
            </body>
        </html>
    `);
}