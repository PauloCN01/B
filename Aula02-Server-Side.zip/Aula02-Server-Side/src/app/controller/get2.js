module.exports = (req, res) => {
    res.send(`
        <html>
            <head>
                <meta charset="utf-8">
            </head>
            <body>
                <h1>Rota Neutra</h1>
                <img src="https://pt.quizur.com/_image?href=https%3A%2F%2Fstatic.quizur.com%2Fi%2Fb%2F599b66049abeb9.95432407599b660489edc1.09315522.jpg&w=400&h=400&f=webp" alt="" height="500px">
            </body>
        </html>
    `);
}